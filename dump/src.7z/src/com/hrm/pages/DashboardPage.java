package com.hrm.pages;

import org.openqa.selenium.WebDriver;

import com.hrm.base.HomePage;

public class DashboardPage extends HomePage{

	public DashboardPage(WebDriver driver) {
		super(driver);
	}

}
