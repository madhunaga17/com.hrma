package com.hrm.javaPrg;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class ScreenshotEx {

	public static void main(String[] args) throws AWTException, Exception {

		Robot r = new Robot();
		Dimension d=Toolkit.getDefaultToolkit().getScreenSize();
		//Rectangle screenRect = new Rectangle(0,0,200,200);//arguments are x,y,width,height
		Rectangle screenRect = new Rectangle(d);
		BufferedImage a = r.createScreenCapture(screenRect);
		ImageIO.write(a, "png", new File("C:/Users/nk/Desktop/Unix docs/Selenium_SW/Screenshot/desktop1.png"));
		
	}

}
