package com.hrm.javaPrg;

import java.util.ArrayList;
import java.util.Collections;

public class CheckIfSorted {

	public static void main(String[] args) {
		ArrayList<String> allText = new ArrayList<String>();
		allText.add("b");
		allText.add("a");
		allText.add("c");
		
		ArrayList<String> clone = new ArrayList<String>(allText);
		Collections.sort(clone);
		
		System.out.println("----------------------------");
		for(int i=0;i<clone.size();i++)
		{
			System.out.println(allText.get(i)+"===="+ clone.get(i));
		}
		System.out.println("----------------------------");
		
		System.out.println(allText.equals(clone));
	}

}
