package com.hrm.javaPrg;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.hrm.base.AutomationConstants;

public class JSDemo implements AutomationConstants{

	public static void main(String[] args) {
		
		System.setProperty(GECKO_KEY, GECKO_VALUE);
		WebDriver driver = new FirefoxDriver();
		driver.get("file:///C:/Users/nk/Desktop/Selenium%20automation/demo2.html");
		
		JavascriptExecutor js= (JavascriptExecutor) driver;
		
//		String script ="document.getElementById('t1').value='manager'";
//		js.executeScript(script);
		
		
//		js.executeScript("document.getElementById('t1').value='manager'");
		
	
//		js.executeScript("document.getElementById('t1').value=arguments[0]","manager");
		
		WebElement e =driver.findElement(By.id("t1"));
		
//		js.executeScript("arguments[0].value='manager'",e);
		
		js.executeScript("arguments[0].value=arguments[1]",e,"manager");
		
// We can receive the arguments to a java script like commandline arguments in main method of java.
//Arguments are stored in args[] array in main method , similarly it is stored in arguments[] array in javascript.
// By using this we can handle the dynamic elements from javascript 
//as we actually identify the element using selenium code(using xpath)
		

	}

}
