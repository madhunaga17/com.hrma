package com.hrm.javaPrg;

import java.util.ArrayList;
import java.util.HashSet;

import generics.Utility;

public class DuplicateInListBox {

	public static void main(String[] args) {
	
		ArrayList<String> allText = new ArrayList<String>();
		allText.add("a");
		allText.add("b");
		allText.add("c");
	
		
	HashSet<String> clone = new HashSet<String>(allText);
		System.out.println(allText.size());
		System.out.println(clone.size());// if both size are equal then no duplicate else duplicate
		
		
		HashSet<String> clone2= new HashSet<String>();
		for(String s:allText)
		{
			boolean v = clone2.add(s);
			System.out.println(v);// here true means text added hence not duplicate but false means text is duplicate
			
			if(!v)
			{
				System.out.println(s);// condition is to check if result is false which means duplicate value.
			}
		}
		
		boolean flag=Utility.checkArrayListHasDuplicate(allText);
		System.out.println(flag);
	}

}
