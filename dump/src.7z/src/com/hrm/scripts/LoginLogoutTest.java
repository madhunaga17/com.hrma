package com.hrm.scripts;

import org.testng.annotations.Test;

import com.hrm.base.BaseTest;

public class LoginLogoutTest extends BaseTest{
	@Test
	public void testAutoLoginLogout(){
		log.info("This script will automatically login and logout");
	}
}
