package com.hrm.scripts;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.hrm.base.BaseTest;

public class TestPhoto extends BaseTest{
	
	@Test
	public void test1()
	{
		Assert.fail();
	}

}
